<?php
echo "Encrypting <b>testing</b> using md5: ".md5("testing");
echo "<br />";
echo "Encrypting <b>testing</b> using sha1: ".sha1("testing");

?>