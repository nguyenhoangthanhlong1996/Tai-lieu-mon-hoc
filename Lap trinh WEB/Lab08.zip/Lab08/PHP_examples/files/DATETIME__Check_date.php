<?php

echo checkdate(4, 31, 2005);

echo checkdate(03, 29, 2004);

echo checkdate(03, 29, 2005);

?>