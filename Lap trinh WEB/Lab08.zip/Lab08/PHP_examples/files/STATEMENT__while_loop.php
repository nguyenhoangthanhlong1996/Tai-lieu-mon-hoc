<?php
$num = 1;

while ($num <= 10){
    print "Number is $num<br />";
    $num++;
}

print 'Done.';
?>
  