<?php
$date_array = getdate();
var_dump($date_array);
?>